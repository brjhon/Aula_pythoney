a = 3
b = 5 
c = 7
d = a + b + c
print (d / 3)
