base = 8
altura = 10

area = (base * altura)/2
print(area) 
