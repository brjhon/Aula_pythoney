a = 3
b = 5
c = 7 
print (a  + b + c)