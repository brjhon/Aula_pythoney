num1 = 10
num2 = 8
num3 = 6
num4 = 4

resultado = ((num1+num2+num3+num4)/4)

print(resultado)