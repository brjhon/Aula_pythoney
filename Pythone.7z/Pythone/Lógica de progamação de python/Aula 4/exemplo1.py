nome = input("Entre com o seu nome:")
sobrenome = input("Entre com o seu sobrenome:")

nomecompleto = nome+ ""+ sobrenome

print(nomecompleto)