
def som (numero): #Criando uma varivel de imortação.
    """ Retorne o dobro do número fornecido """
    return numero + 2
    #O comando "Return" serv para retornar o calculo ou outra coisa que for feita.

def dobro (numero):
    """ Retorne o dobro do número fornecido """
    return numero * 2
    #Pode ser feito de varias maneiras os calculos.

def Div (numero):
    """ Retorne o dobro do número fornecido """
    return numero / 2

def Sub (numero):
    """ Retorne o dobro do número fornecido """
    return numero - 2