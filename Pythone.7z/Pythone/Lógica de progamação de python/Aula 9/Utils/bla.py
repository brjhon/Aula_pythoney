def dobro (numero):
    """ Retorna o dobro do número fornecido """
    return numero * 2