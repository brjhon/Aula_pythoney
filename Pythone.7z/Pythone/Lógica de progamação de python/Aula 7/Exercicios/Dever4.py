print("Números pares entre 100 e 125: ")
for numero_par in range(102,124,2):
    print(numero_par)


print("Números ímpares entre 100 e 125: ")
for numero_impar in range(101,124,2):
    print(numero_impar)
