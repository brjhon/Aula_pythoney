
num_repeticoes = 11 
for segundo in range(num_repeticoes):
    print(f"Cronômetro: {segundo} segundos")
    