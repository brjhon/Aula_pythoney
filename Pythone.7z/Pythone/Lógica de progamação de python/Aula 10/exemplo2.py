#Criar uma lista de números desordenados
lista_numeros = [5, 2, 9, 1, 5, 6]
# Criação de planilha.
print("Lista original:", lista_numeros)

#Ordenar a lista
lista_numeros.sort() # organização de uma lista bagunçada 
print("Lista ordenada: ", lista_numeros)