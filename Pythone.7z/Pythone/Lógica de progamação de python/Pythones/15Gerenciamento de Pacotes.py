# Exemplo de instalação de pacote com pip
#$ pip install numpy
