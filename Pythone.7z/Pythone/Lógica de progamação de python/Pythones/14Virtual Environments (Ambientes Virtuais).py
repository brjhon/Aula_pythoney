

# Exemplo de criação de ambiente virtual
# No terminal
#$ python -m venv myenv
#$ source myenv/bin/activate  # Ativar ambiente virtual (Linux/Mac)
#$ myenv\Scripts\activate      # Ativar ambiente virtual (Windows)
