#Manipulação de Strings

# Exemplo de manipulação de strings
frase = "Python é incrível"
print(frase.upper())  # Saída: PYTHON É INCRÍVEL
print(frase.split())  # Saída: ['Python', 'é', 'incrível']
