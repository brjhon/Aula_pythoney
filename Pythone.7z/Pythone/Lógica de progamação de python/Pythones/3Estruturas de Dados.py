#Estruturas de Dados

# Exemplo de estrutura de dados
lista = [1, 2, 3, 4, 5]
tupla = (1, 2, 3)
dicionario = {"nome": "João", "idade": 25}
conjunto = {1, 2, 3, 4, 5}
