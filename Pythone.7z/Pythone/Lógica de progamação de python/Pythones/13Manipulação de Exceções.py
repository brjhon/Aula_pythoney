#Manipulação de Exceções

# Exemplo de manipulação de exceções
try:
    resultado = 10 / 0
except ZeroDivisionError:
    print("Erro: Divisão por zero!")
