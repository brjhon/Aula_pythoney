#Estruturas de Controle

# Exemplo de estrutura de controle
idade = 18
if idade >= 18:
    print("Você é maior de idade.")
else:
    print("Você é menor de idade.")
