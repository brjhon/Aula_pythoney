#Compreensão de Lista

# Exemplo de compreensão de lista
quadrados = [x ** 2 for x in range(10)]
# Ela segue a sintaxe geral "[expressão for item in iterável]"

print(quadrados)  # Saída: [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]
#Imprime a lista resultante da copreensão de lista.