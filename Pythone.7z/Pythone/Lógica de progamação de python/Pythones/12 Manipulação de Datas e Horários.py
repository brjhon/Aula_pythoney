# Manipulação de Datas e Horários

# Exemplo de manipulação de datas
import datetime
hoje = datetime.date.today()reverse()
print(hoje)  # Saída: YYYY-MM-DD
