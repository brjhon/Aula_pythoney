#Variáveis e Tipos de Dados

# Exemplo de variáveis
nome = "João"
idade = 25
altura = 1.75
