#Funções

# Exemplo de função
def saudacao(nome): #Esta linha define a função "saudacao" como paremetro
    print("Olá, " + nome + "!") 
    #Esta linha imprime uma mensagem seguida pelo nome que foi passado como argumento para a função

saudacao("Maria")
