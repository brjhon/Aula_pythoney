#Módulos e Bibliotecas

# Exemplo de importação de biblioteca
import math
print(math.sqrt(25))  # Saída: 5.0
