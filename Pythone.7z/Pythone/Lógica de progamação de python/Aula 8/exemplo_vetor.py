#lista pré-preenchida com algumas informações
informacoes = ["Alice", 30, "Engenheiro", 2, "rio de janeiro"]

#Imprimir a lista completa
print("lista Completa:")
print(informacoes)

#Imprimir cada elemento da lista em uma nova linha
print("\nElementos da lista: ")
for info in informacoes:
    print(info)