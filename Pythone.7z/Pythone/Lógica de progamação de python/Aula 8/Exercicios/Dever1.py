#transferencia de tabela do excel para o python
#8:00, 9:00, 10:00, 11:00, 12:00, 13:00, 14:00, 15:00, 16:00, 17:00
#refletir sobre oque fazer	analizar dados	Rever dados passados	Ajudar em casa, limpar	Ajudar a fazer o almoço caso não tenho. Almoçar	Fazer alguns exercícios	Estudar Html e css	Fazer algo que não tenho terminado	Continuar fazendo 	Brincar um pouco

Dadoshorario = ["refletir sobre oque fazer", 8, "Analizar dados", 9, "Rever dados passados",  10, "Ajudar em casa, limpar", 11, "Ajudar a fazer o almoço caso não tenho. Almoçar", 12, "Fazer alguns exercícios", 13, "Estudar Html e css", 14, "Fazer algo que não tenho terminado", 15, "Continuar Fazendo", 16, "Brincar", 17]

print("Complet list")
print(Dadoshorario)

print("\nDados da lista")
for info in Dadoshorario:
    print(info)