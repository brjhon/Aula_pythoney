#Faça um software para a decolagem 
print("Contagem regressiva")

contador = 100
while contador <= 125:
    print(contador)
    contador = contador + 2

contador = 101 
while contador <= 125:
    print(contador)
    contador = contador + 1

