# Faça um progama que calcule de 0 20 so comnúmeros pares

contador = 0 
while contador <= 19:
    print(contador)
    contador = contador + 2 

