# Faça um processamento que leia de 20 a 40 so com números impares

contador = 21
while contador <= 40:
    print(contador)
    contador = contador + 2

