#Esse programa e um liping infinito ate a varial ser verdadeira
contador = 1 
while contador <= 10:
    print(contador)#inicio do luping
    contador = contador + 1 #ele somara ate 10
