/* alert('ola');
console.log('ola');


if (may_var%2 == 0){
    alert('Número par');
}
else if (my_var%2 == 1){
    alert('Número ímpar');
}
else{
    alert('valor invalido')
} */

var nome = prompt("digite seu nome: ");
alert(none); 
